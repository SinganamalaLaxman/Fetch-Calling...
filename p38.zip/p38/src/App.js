import logo from './logo.svg';
import './App.css';
import {useState} from 'react';

function App() {
  let [jeweleryProduct,setJeweleryProduct] = useState([]);
  let APICalling = async()=>{
    let optMethod = {
      "method":"GET"
    }
    let JSONData = await fetch("https://fakestoreapi.com/products/category/jewelery",optMethod);
    let JSOData = await JSONData.json();
    setJeweleryProduct(JSOData);
    console.log(JSOData);
  }
  return (
    <div className="App">
    <button onClick = {()=>{
      APICalling()
    }}>Fetch API </button>
    <div className='container'>
    {jeweleryProduct.map((obj)=>{
      return <div className='box-container'>
      <img className = "imagePic"src = {obj.image}></img>
      <h5>{obj.title}</h5>
      </div>
     
      

    })}
    </div>
    </div>
  );
}

export default App;
